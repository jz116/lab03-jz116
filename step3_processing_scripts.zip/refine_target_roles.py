from pathlib import Path

from pyspark import StorageLevel
from pyspark.sql import SparkSession
from pyspark.sql import functions as F


data_dir = Path("data/MET_CareerCompass_2026")
spark_tmp = Path(".spark-tmp")
spark_tmp.mkdir(exist_ok=True)

parquet_files = sorted(str(path) for path in data_dir.rglob("*.parquet"))

if len(parquet_files) != 17:
    raise RuntimeError(
        f"Expected 17 Parquet files, but found {len(parquet_files)}."
    )

spark = (
    SparkSession.builder
    .appName("RefineTargetRoles")
    .config("spark.local.dir", str(spark_tmp.resolve()))
    .getOrCreate()
)

spark.sparkContext.setLogLevel("ERROR")

columns = [
    "ID",
    "POSTED",
    "TITLE_RAW",
    "TITLE_NAME",
    "TITLE_CLEAN",
    "ONET_NAME",
    "SOC_5",
    "SOC_5_NAME",
    "NAICS_2022_6",
    "NAICS_2022_6_NAME",
    "COMPANY_NAME",
    "CITY_NAME",
    "STATE_NAME",
]

raw = spark.read.parquet(*parquet_files).select(*columns)

industry = (
    raw.filter(
        F.coalesce(F.col("NAICS_2022_6"), F.lit("")).contains("513210")
        | F.lower(
            F.coalesce(F.col("NAICS_2022_6_NAME"), F.lit(""))
        ).contains("software publishers")
    )
    .dropDuplicates(["ID"])
    .persist(StorageLevel.DISK_ONLY)
)

print(f"\nSoftware Publishers postings: {industry.count():,}")

profile = (
    industry
    .withColumn(
        "_title_text",
        F.lower(
            F.concat_ws(
                " ",
                F.coalesce(F.col("TITLE_RAW"), F.lit("")),
                F.coalesce(F.col("TITLE_NAME"), F.lit("")),
                F.coalesce(F.col("TITLE_CLEAN"), F.lit("")),
            )
        ),
    )
    .withColumn(
        "_occupation_text",
        F.lower(
            F.concat_ws(
                " ",
                F.coalesce(F.col("ONET_NAME"), F.lit("")),
                F.coalesce(F.col("SOC_5_NAME"), F.lit("")),
            )
        ),
    )
)

title_text = F.col("_title_text")
occupation_text = F.col("_occupation_text")

data_scientist = (
    title_text.rlike(r"\bdata scientists?\b")
    | occupation_text.rlike(r"\bdata scientists?\b")
)

machine_learning = (
    title_text.rlike(r"\b(machine learning|ml)\b")
    & title_text.rlike(r"\b(engineer|scientist)\b")
)

applied_decision = title_text.rlike(
    r"\b(applied|decision) scientists?\b"
)

ai_role = (
    title_text.rlike(r"\b(ai|artificial intelligence)\b")
    & title_text.rlike(r"\b(engineer|scientist)\b")
)

analytics_engineer = title_text.rlike(r"\banalytics engineers?\b")

research_scientist = (
    title_text.rlike(r"\bresearch scientists?\b")
    & title_text.rlike(
        r"\b(data|machine learning|ml|ai|artificial intelligence)\b"
    )
)

profile = profile.withColumn(
    "ROLE_SEGMENT",
    F.when(data_scientist, "Data Scientist")
    .when(machine_learning, "Machine Learning Engineer/Scientist")
    .when(applied_decision, "Applied or Decision Scientist")
    .when(ai_role, "AI Engineer/Scientist")
    .when(analytics_engineer, "Analytics Engineer")
    .when(research_scientist, "Data/AI Research Scientist"),
)

print("\nAudit of the original three matches:")

original_matches = profile.filter(
    F.concat_ws(
        " ",
        F.col("_title_text"),
        F.col("_occupation_text"),
    ).contains("data scien")
)

original_matches.select(
    "ID",
    "TITLE_RAW",
    "TITLE_NAME",
    "TITLE_CLEAN",
    "ONET_NAME",
    "SOC_5",
    "SOC_5_NAME",
    "COMPANY_NAME",
).show(20, truncate=False)

print("\nCounts under the broader career-pathway definition:")

profile.filter(
    F.col("ROLE_SEGMENT").isNotNull()
).groupBy(
    "ROLE_SEGMENT"
).count().orderBy(
    F.desc("count")
).show(truncate=False)

print("\nCandidate titles and occupation mappings:")

profile.filter(
    F.col("ROLE_SEGMENT").isNotNull()
).groupBy(
    "ROLE_SEGMENT",
    "TITLE_CLEAN",
    "ONET_NAME",
    "SOC_5_NAME",
).count().orderBy(
    "ROLE_SEGMENT",
    F.desc("count"),
).show(100, truncate=False)

broad_term = (
    title_text.rlike(
        r"\b(data|analytics|scientist|machine learning|ml|ai|artificial intelligence)\b"
    )
    | occupation_text.rlike(
        r"\b(data|analytics|scientist|machine learning|ml|ai|artificial intelligence)\b"
    )
)

print("\nRelated postings not assigned to a pathway segment:")

profile.filter(
    F.col("ROLE_SEGMENT").isNull() & broad_term
).groupBy(
    "TITLE_CLEAN",
    "ONET_NAME",
    "SOC_5_NAME",
).count().orderBy(
    F.desc("count")
).show(100, truncate=False)

print("\nFull Software Publishers date window:")

industry.select(
    F.min(F.to_date("POSTED")).alias("earliest_posting"),
    F.max(F.to_date("POSTED")).alias("latest_posting"),
    F.countDistinct("ID").alias("unique_jobs"),
).show(truncate=False)

industry.unpersist()
spark.stop()

print("\nRole-filter refinement completed.")
