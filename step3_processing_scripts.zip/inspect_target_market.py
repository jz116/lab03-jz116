import os
from pathlib import Path

from pyspark import StorageLevel
from pyspark.sql import SparkSession
from pyspark.sql import functions as F


repo_dir = Path(__file__).resolve().parent
data_dir = repo_dir / "data" / "MET_CareerCompass_2026"
spark_temp_dir = repo_dir / ".spark-tmp"
spark_temp_dir.mkdir(exist_ok=True)

os.environ["SPARK_LOCAL_DIRS"] = str(spark_temp_dir)

parquet_files = sorted(data_dir.rglob("*.parquet"))

if len(parquet_files) != 17:
    raise RuntimeError(
        f"Expected 17 Parquet files; found {len(parquet_files)}"
    )

spark = (
    SparkSession.builder
    .appName("TargetMarketInspection")
    .master("local[2]")
    .config("spark.sql.shuffle.partitions", "8")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("WARN")

try:
    raw = spark.read.parquet(
        *[str(path) for path in parquet_files]
    )

    selected = raw.select(
        "ID",
        "POSTED",
        "TITLE_RAW",
        "TITLE_CLEAN",
        "TITLE_NAME",
        "ONET_NAME",
        "SOC_5_NAME",
        "NAICS_2022_6",
        "NAICS_2022_6_NAME",
        "COMPANY_NAME",
        "CITY_NAME",
        "STATE_NAME",
        "SALARY_FROM",
        "SALARY_TO",
        "ORIGINAL_PAY_PERIOD",
        "MIN_YEARS_EXPERIENCE",
        "MAX_YEARS_EXPERIENCE",
        "MIN_EDULEVELS_NAME",
        "EMPLOYMENT_TYPE_NAME",
        "REMOTE_TYPE_NAME",
        "SKILLS_NAME",
        "SPECIALIZED_SKILLS_NAME",
        "SOFTWARE_SKILLS_NAME",
    )

    industry = (
        selected
        .filter(F.col("ID").isNotNull())
        .filter(
            F.col("NAICS_2022_6").contains("513210")
            | F.lower(
                F.coalesce(
                    F.col("NAICS_2022_6_NAME"),
                    F.lit(""),
                )
            ).contains("software publishers")
        )
        .dropDuplicates(["ID"])
        .persist(StorageLevel.DISK_ONLY)
    )

    print(
        f"\nUnique Software Publishers postings: "
        f"{industry.count():,}"
    )

    print("\nTop standardized titles:")
    (
        industry
        .groupBy("TITLE_CLEAN")
        .count()
        .orderBy(F.desc("count"))
        .show(50, truncate=False)
    )

    role_text = F.lower(
        F.concat_ws(
            " ",
            F.coalesce(F.col("TITLE_RAW"), F.lit("")),
            F.coalesce(F.col("TITLE_CLEAN"), F.lit("")),
            F.coalesce(F.col("TITLE_NAME"), F.lit("")),
            F.coalesce(F.col("ONET_NAME"), F.lit("")),
            F.coalesce(F.col("SOC_5_NAME"), F.lit("")),
        )
    )

    candidates = (
        industry
        .filter(role_text.contains("data scien"))
        .persist(StorageLevel.DISK_ONLY)
    )

    print(
        f"\nPotential Data Scientist postings: "
        f"{candidates.count():,}"
    )

    print("\nCandidate titles:")
    (
        candidates
        .groupBy("TITLE_CLEAN")
        .count()
        .orderBy(F.desc("count"))
        .show(50, truncate=False)
    )

    print("\nCandidate occupation classifications:")
    (
        candidates
        .groupBy("ONET_NAME", "SOC_5_NAME")
        .count()
        .orderBy(F.desc("count"))
        .show(30, truncate=False)
    )

    print("\nCandidate date and salary coverage:")
    (
        candidates
        .agg(
            F.min("POSTED").alias("earliest_posting"),
            F.max("POSTED").alias("latest_posting"),
            F.countDistinct("ID").alias("unique_jobs"),
            F.sum(
                F.when(
                    F.col("SALARY_FROM").isNotNull()
                    | F.col("SALARY_TO").isNotNull(),
                    1,
                ).otherwise(0)
            ).alias("jobs_with_salary"),
        )
        .show(vertical=True)
    )

    print("\nRemote-status distribution:")
    (
        candidates
        .groupBy("REMOTE_TYPE_NAME")
        .count()
        .orderBy(F.desc("count"))
        .show(20, truncate=False)
    )

    print("\nMinimum-education distribution:")
    (
        candidates
        .groupBy("MIN_EDULEVELS_NAME")
        .count()
        .orderBy(F.desc("count"))
        .show(20, truncate=False)
    )

    candidates.unpersist()
    industry.unpersist()

finally:
    spark.stop()
