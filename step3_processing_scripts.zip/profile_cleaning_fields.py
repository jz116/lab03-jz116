from pathlib import Path

from pyspark import StorageLevel
from pyspark.sql import SparkSession
from pyspark.sql import functions as F


data_dir = Path("data/MET_CareerCompass_2026")
spark_tmp = Path(".spark-tmp")
spark_tmp.mkdir(exist_ok=True)

parquet_files = sorted(str(path) for path in data_dir.rglob("*.parquet"))

if len(parquet_files) != 17:
    raise RuntimeError(
        f"Expected 17 Parquet files, found {len(parquet_files)}."
    )

spark = (
    SparkSession.builder
    .appName("ProfileCleaningFields")
    .config("spark.local.dir", str(spark_tmp.resolve()))
    .getOrCreate()
)

spark.sparkContext.setLogLevel("ERROR")

columns = [
    "ID",
    "DUPLICATES",
    "POSTED",
    "EXPIRED",
    "TITLE_RAW",
    "TITLE_NAME",
    "TITLE_CLEAN",
    "COMPANY_NAME",
    "COMPANY_RAW",
    "COMPANY_IS_STAFFING",
    "EDUCATION_LEVELS_NAME",
    "MIN_EDULEVELS_NAME",
    "MAX_EDULEVELS_NAME",
    "EMPLOYMENT_TYPE_NAME",
    "MIN_YEARS_EXPERIENCE",
    "MAX_YEARS_EXPERIENCE",
    "IS_INTERNSHIP",
    "SALARY",
    "SALARY_FROM",
    "SALARY_TO",
    "ORIGINAL_PAY_PERIOD",
    "REMOTE_TYPE_NAME",
    "LOCATION",
    "CITY_NAME",
    "COUNTY_NAME",
    "STATE_NAME",
    "SKILLS_NAME",
    "SPECIALIZED_SKILLS_NAME",
    "SOFTWARE_SKILLS_NAME",
    "ONET_NAME",
    "SOC_5",
    "SOC_5_NAME",
    "NAICS_2022_6",
    "NAICS_2022_6_NAME",
]

raw = spark.read.parquet(*parquet_files).select(*columns)

industry = raw.filter(
    F.coalesce(F.col("NAICS_2022_6"), F.lit("")).contains("513210")
    | F.lower(
        F.coalesce(F.col("NAICS_2022_6_NAME"), F.lit(""))
    ).contains("software publishers")
).dropDuplicates(["ID"])

profile = (
    industry
    .withColumn(
        "_title_text",
        F.lower(
            F.concat_ws(
                " ",
                F.coalesce(F.col("TITLE_RAW"), F.lit("")),
                F.coalesce(F.col("TITLE_CLEAN"), F.lit("")),
            )
        ),
    )
    .withColumn(
        "_mapping_text",
        F.lower(
            F.concat_ws(
                " ",
                F.coalesce(F.col("TITLE_NAME"), F.lit("")),
                F.coalesce(F.col("ONET_NAME"), F.lit("")),
                F.coalesce(F.col("SOC_5_NAME"), F.lit("")),
            )
        ),
    )
)

title_text = F.col("_title_text")
mapping_text = F.col("_mapping_text")

explicit_data_scientist = title_text.rlike(r"\bdata scientists?\b")

data_science_leadership = (
    title_text.rlike(r"\bdata science\b")
    & title_text.rlike(
        r"\b(scientist|analyst|manager|director|lead|intern)\b"
    )
)

mapped_data_scientist = mapping_text.rlike(r"\bdata scientists?\b")

ml_term = title_text.rlike(
    r"machine learning|(^|[^a-z0-9])ml([^a-z0-9]|$)"
)

# Avoid treating a '.ai' web address as an AI role.
ai_term = title_text.rlike(
    r"artificial intelligence|(^|[^a-z0-9.])ai([^a-z0-9]|$)"
)

technical_role = title_text.rlike(
    r"\b(engineer|scientist|developer|architect|intern)\b"
)

applied_decision = title_text.rlike(
    r"\b(applied|decision) scientists?\b"
)

research_scientist = (
    title_text.rlike(r"\bresearch scientists?\b")
    & (
        title_text.rlike(r"\bdata science\b")
        | ml_term
        | ai_term
    )
)

analytics_engineer = title_text.rlike(
    r"\banalytics engineers?\b"
)

role_segment = (
    F.when(
        explicit_data_scientist
        | data_science_leadership
        | mapped_data_scientist,
        "Data Scientist",
    )
    .when(applied_decision, "Applied or Decision Scientist")
    .when(research_scientist, "Data/AI Research Scientist")
    .when(ml_term & technical_role, "Machine Learning Technical Role")
    .when(ai_term & technical_role, "AI Technical Role")
    .when(analytics_engineer, "Analytics Engineer")
)

cohort = (
    profile
    .withColumn("ROLE_SEGMENT", role_segment)
    .filter(F.col("ROLE_SEGMENT").isNotNull())
    .withColumn(
        "SCOPE_TIER",
        F.when(
            F.col("ROLE_SEGMENT") == "Data Scientist",
            "Core",
        ).otherwise("Adjacent"),
    )
    .persist(StorageLevel.DISK_ONLY)
)

cohort_count = cohort.count()

print(f"\nFinal candidate cohort: {cohort_count:,}")

print("\nScope and role counts:")

cohort.groupBy(
    "SCOPE_TIER",
    "ROLE_SEGMENT",
).count().orderBy(
    "SCOPE_TIER",
    F.desc("count"),
).show(truncate=False)

print("\nTitles included by the corrected filter:")

cohort.groupBy(
    "SCOPE_TIER",
    "ROLE_SEGMENT",
    "TITLE_RAW",
    "SOC_5_NAME",
).count().orderBy(
    "SCOPE_TIER",
    "ROLE_SEGMENT",
    F.desc("count"),
).show(100, truncate=False)

fields_to_check = [
    "POSTED",
    "EXPIRED",
    "TITLE_CLEAN",
    "COMPANY_NAME",
    "SALARY_FROM",
    "SALARY_TO",
    "ORIGINAL_PAY_PERIOD",
    "MIN_YEARS_EXPERIENCE",
    "MAX_YEARS_EXPERIENCE",
    "MIN_EDULEVELS_NAME",
    "EMPLOYMENT_TYPE_NAME",
    "REMOTE_TYPE_NAME",
    "CITY_NAME",
    "STATE_NAME",
    "SKILLS_NAME",
    "SPECIALIZED_SKILLS_NAME",
    "SOFTWARE_SKILLS_NAME",
]

missing_expressions = []

for field_name in fields_to_check:
    is_missing = (
        F.col(field_name).isNull()
        | (F.trim(F.col(field_name)) == "")
    )

    missing_expressions.append(
        F.sum(
            F.when(is_missing, 1).otherwise(0)
        ).alias(field_name)
    )

missing_counts = cohort.agg(*missing_expressions).first().asDict()

print("\nMissing-value report:")

for field_name in fields_to_check:
    missing = missing_counts[field_name]
    nonmissing = cohort_count - missing
    percent = 100 * missing / cohort_count if cohort_count else 0

    print(
        f"{field_name}: "
        f"nonmissing={nonmissing}, "
        f"missing={missing} ({percent:.1f}%)"
    )


def show_distribution(field_name, limit=30):
    normalized = F.when(
        F.col(field_name).isNull()
        | (F.trim(F.col(field_name)) == ""),
        "Missing",
    ).otherwise(F.trim(F.col(field_name)))

    print(f"\nDistribution: {field_name}")

    cohort.select(
        normalized.alias(field_name)
    ).groupBy(
        field_name
    ).count().orderBy(
        F.desc("count")
    ).show(limit, truncate=False)


distribution_fields = [
    "REMOTE_TYPE_NAME",
    "EMPLOYMENT_TYPE_NAME",
    "MIN_EDULEVELS_NAME",
    "MIN_YEARS_EXPERIENCE",
    "MAX_YEARS_EXPERIENCE",
    "ORIGINAL_PAY_PERIOD",
    "IS_INTERNSHIP",
    "STATE_NAME",
]

for field_name in distribution_fields:
    show_distribution(field_name)


def numeric_value(field_name):
    extracted = F.regexp_extract(
        F.regexp_replace(
            F.coalesce(F.col(field_name), F.lit("")),
            ",",
            "",
        ),
        r"-?\d+(?:\.\d+)?",
        0,
    )

    return F.when(
        F.length(extracted) > 0,
        extracted.cast("double"),
    ).otherwise(F.lit(None).cast("double"))


print("\nPreliminary numeric salary summary:")

cohort.select(
    numeric_value("SALARY_FROM").alias("salary_from_numeric"),
    numeric_value("SALARY_TO").alias("salary_to_numeric"),
).summary(
    "count",
    "min",
    "25%",
    "50%",
    "75%",
    "max",
).show(truncate=False)

print("\nRaw salary examples:")

cohort.filter(
    F.col("SALARY_FROM").isNotNull()
    | F.col("SALARY_TO").isNotNull()
).select(
    "TITLE_RAW",
    "SALARY",
    "SALARY_FROM",
    "SALARY_TO",
    "ORIGINAL_PAY_PERIOD",
).show(25, truncate=False)

print("\nSkill-field examples:")

cohort.filter(
    F.col("SKILLS_NAME").isNotNull()
    | F.col("SPECIALIZED_SKILLS_NAME").isNotNull()
    | F.col("SOFTWARE_SKILLS_NAME").isNotNull()
).select(
    "TITLE_RAW",
    "SKILLS_NAME",
    "SPECIALIZED_SKILLS_NAME",
    "SOFTWARE_SKILLS_NAME",
).show(10, truncate=False)

print("\nPossible near-duplicate groups:")

cohort.groupBy(
    "COMPANY_NAME",
    "TITLE_RAW",
    "POSTED",
    "CITY_NAME",
    "STATE_NAME",
).count().filter(
    F.col("count") > 1
).orderBy(
    F.desc("count")
).show(50, truncate=False)

print("\nCandidate date window:")

cohort.select(
    F.min(F.to_date("POSTED")).alias("earliest_posting"),
    F.max(F.to_date("POSTED")).alias("latest_posting"),
    F.countDistinct("ID").alias("unique_jobs"),
).show(truncate=False)

cohort.unpersist()
spark.stop()

print("\nCleaning-field profile completed.")
